/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.Connector;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Hunter
 */
public class Connector {
    
    
      // get connection method, returns null if it doesn't work
    public static Connection getConnection() throws Exception{
        try{
            // unnecesary but i'm following the tutorial
            String driver = "com.mysql.cj.jdbc.Driver";
            // found under connection properties
            String URL = "jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=CONVERT_TO_NULL";
            // username and password i set for myself in server
            String username = "hunter";
            String password = "hunter";
            // loads driver, again unnecessary
            Class.forName(driver);
            
            Connection con = DriverManager.getConnection(URL, username, password);
            System.out.println("Connected to " + URL);
            return con;
            
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    // end getConnection()
    
    
}
// end class