/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.databaseGUI;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Hunter Flory
 */
public class Connector {
    
    
    // UNFINISHED, DON'T USE
    // clear all method
    // WARNING:
    // This function clears all rows in all tables
    // Use it to clear all tables if you inserted files twice or need to test
    public static void clearAll()
    {
        System.out.println("CLEARING TABLES...\n");
        // NOT FINISHED
    }
    // END CLEARALL
    
    
    // create customer query
    // on hitting enter, text in fields will be converted to parameters for this function
    // and newCustomer() will be called
    public static void newCustomer(String name, String areaCode, String mid, String last)
    {
        String phoneNumber = "("+areaCode+") "+mid+"-"+last;
        // custID is auto generated so null is provided for field 1 
        String query = "INSERT INTO customer VALUES "
                + "(" + null + "," + name + "," + phoneNumber + ");";
        
        try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
    }
    // end customer
    
    
    
    
    // create vehicle query
    public static void newVehicle(String vin, String description, String year, String type, String category)
    {
        String query = "INSERT INTO vehicle VALUES "
                +"(" + vin + "," + description + "," + year + "," + type + "," + category + ");";
        
        try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
        
    }
    // end vehicle
    
    // create rental query
    // User performs search of available rentals with information,
    // User selects vehicle from available rentals,
    // User selects customer from accounts,
    // User selects payment date option,
    // User clicks enter
    // This method is called with parsed string from row clicked in each table
    // this method delimits strings and creates new rental from relevant data
    // db is updated
    
    // CustID, VIN, and Total amount will be found from selected rows
    public static void newRental(String custID, String vin, String startDate, String orderDate, String rentalType, String qty, String returnDate,
    String totalAmount, String paymentDate, String returned)
    {
        String query = "INSERT INTO rental VALUES "+
                "("+custID+ "," + vin + ","+ startDate + "," + orderDate+ "," 
                 +rentalType+ ","+ qty+ ","+returnDate+ ","+totalAmount+ ","+paymentDate+ ","+returned+");";
        
        try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
        
    }
                
                
    
    // end rental
    
    
    
    // create returns query
    public static void returnRental(String returnDate, String custName, String vin)
    {
        String query = "SELECT RentalBalance FROM vrentalinfo WHERE " +
                "ReturnDate = " + returnDate + " AND CustomerName = " + custName +
                " AND VIN = " + vin;
        
        try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.execute();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
    }
    // end returns
    
    // view query
    // balance and start date will be passed in as ASC or DESC
    public static void getByFilter_rentalView(String custID, String name, String vin, String balance, String startDate, String type, String category)
    {
        
        String query = "SELECT * FROM vrentalinfo WHERE "+
                "CustomerID = "+ custID + " AND CustomerName = '" + name + 
                "' AND VIN = '" + vin+"'"; //+ " AND Type = " + type + " AND Category = " + category;
        String result;
        
        if (type != null)
            query += " AND Type = '" + type + "'";
        if (category != null)
            query += " AND Category = '" + category + "'"; 
        if (balance != null)
            query += " ORDER BY RentalBalance "+balance;
        if (startDate != null)
            query += " ORDER BY StartDate "+startDate;
      
        try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                Statement statement = connection.createStatement();
                ResultSet rs = statement.executeQuery(query);
                
                // code that prints rental balance and start date of each returned row to verify code is working
                /*
                while (rs.next())
                {
                    String RentalBalance = rs.getString("RentalBalance");
                    String StartDate = rs.getString("StartDate");
                    System.out.println(RentalBalance);
                    System.out.println(StartDate);
                }
                */
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
        
    }
    // end view
    
    
    
    
    
    
      // get connection method, returns null if it doesn't work
    public static Connection getConnection() throws Exception{
        try{
            // unnecesary but i'm following the tutorial
            String driver = "com.mysql.cj.jdbc.Driver";
            // found under connection properties
            String URL = "jdbc:mysql://localhost:3306/project2v3";
            // username and password i set for myself in server
            String username = "hunter";
            String password = "hunter";
            // loads driver, again unnecessary
            Class.forName(driver);
            
            Connection con = DriverManager.getConnection(URL, username, password);
            System.out.println("Connected to " + URL);
            return con;
            
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    // end getConnection()
    
    
    
    public static void main(String args[])
    {
        System.out.println("Getting connection to database");
        try {
            getConnection();
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
        
        // call loader function
        
            
    }
    
    
}
// end class