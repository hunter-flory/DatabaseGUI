/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hunter
 */
import java.sql.*;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class Insert
{

    // call this function with the full filename as a parameter to open it
    // and scan for database entries
    // THIS IS INCOMPLETE
    public static void insertToTable(String fileName)
    {
        
        try (Scanner input = new Scanner(new File(fileName)))
        {

            switch (fileName) // parse each file differently depending on datatype/name
            {
                case "DEPARTMENT.txt" -> {
                    String name, dept_num, manager_num, date;
                    String insertDept;
                    // this while statement breaks down the Department data 
                    // into variables for insert
                    while (input.hasNextLine())
                    {

                        String line = input.nextLine();
                        String delims = "[,\n]";
                        String[] tokens = line.split(delims);

                        //System.out.println(line);
                        //input.useDelimiter(", ");
                        //name = input.next();
                        name = tokens[0];
                        //input.useDelimiter(", ");
                        //dept_num = input.next();
                        dept_num = tokens[1];
                        //input.useDelimiter(", ");
                        //manager_num = input.next();
                        manager_num = tokens[2];
                        //input.useDelimiter(", ");
                        //date = input.next();
                        date = tokens[3];
                        
                        //System.out.println(tokens[0]);
                        //System.out.println(tokens[1]);
                        //System.out.println(tokens[2]);
                        //System.out.println(tokens[3]);
                        // this string is the SQL query
                        insertDept = "INSERT INTO department VALUES "
                                + "(" + name + ", " + dept_num + ", " + manager_num + ", " + date + ");";
                        System.out.println(insertDept);                        
                        
                        // our variables printed
                        //System.out.println("(" + name + ", " + dept_num + ", " + manager_num + ", " + date + ")");
                        try 
                        {
                            // this gets a connection with provided parameters from getConnection method we created
                            Connection connection = getConnection();
                            PreparedStatement prepsInsertProduct = connection.prepareStatement(insertDept);
                            prepsInsertProduct.executeUpdate();
                            
                            //resultSet = prepsInsertProduct.getGeneratedKeys();
                               
                        }
                        catch (Exception e)
                        {
                            System.out.println(e);
                        }
                    }
                }
                case "DEPT_LOCATIONS.txt" -> {
                    // DEPT_LOCATIONS just has locations
                    while (input.hasNextLine())
                    {
                        System.out.println(input.nextLine());
                    }
                }
                case "EMPLOYEE.txt" -> {
                }
                case "PROJECT.txt" -> {
                }
                case "WORKS_ON.txt" -> {
                }
                default -> System.out.println("File not supported. Use files found in src/Database_Entries");
            }
                
        }
        catch (IOException e)
        {
            System.out.println(e);
        }
    }
    
    // get connection method, returns null if it doesn't work
    public static Connection getConnection() throws Exception{
        try{
            // unnecesary but i'm following the tutorial
            String driver = "com.mysql.cj.jdbc.Driver";
            // found under connection properties
            String URL = "jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=CONVERT_TO_NULL";
            // username and password i set for myself in server
            String username = "hunter";
            String password = "hunter";
            // loads driver, again unnecessary
            Class.forName(driver);
            
            Connection con = DriverManager.getConnection(URL, username, password);
            return con;
            //System.out.println("Connection Established.");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    public static void main(String[] args) throws Exception
    {
        // connection is established through netbeans to sql server
        // INSTRUCTIONS: under 'Services', right click 'Databases' and click 'New Connection'
        // Select the driver you are using for the connection (I'm using Connector J 8.0.21 found from MySQL Community Installer)
        // Browse for the file path to the driver jar you downloaded 
        // Use 'localhost' as Host, port as 3306, and the name of the database ('mysql', or whatever you changed it to)
        // The username and passwords I set up for my local server is your lowercase first name for both
        // Test the connection to see if it worked and you're done. 
        // Your connection should now show up under the 'Services' tab
        // You can find 'mydb' under 'Other databases'
        
        
        // TODO: finish readFile function and write prepared statements to insert 
        // data files into tables
        //System.out.println("Beginning Program");
        getConnection();
        insertToTable("DEPARTMENT.txt");
    }
}
