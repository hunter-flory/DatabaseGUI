/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.Connector;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Hunter Flory
 */
public class Connector {
    
    
    // clear all method
    // WARNING:
    // This function clears all rows in all tables
    // Use it to clear all tables if you inserted files twice or need to test
    public static void clearAll()
    {
        System.out.println("CLEARING TABLES...\n");
                   
    }
    // END CLEARALL
    
    
    // create customer query
    
    // end customer
    
    // create vehicle query
    
    // end vehicle
    
    // create rental query
    
    // end rental
    
    // create returns query
    
    // end returns
    
    // end view query
    
    // end view
    
    
    
    
    
    
      // get connection method, returns null if it doesn't work
    public static Connection getConnection() throws Exception{
        try{
            // unnecesary but i'm following the tutorial
            String driver = "com.mysql.cj.jdbc.Driver";
            // found under connection properties
            String URL = "jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=CONVERT_TO_NULL";
            // username and password i set for myself in server
            String username = "hunter";
            String password = "hunter";
            // loads driver, again unnecessary
            Class.forName(driver);
            
            Connection con = DriverManager.getConnection(URL, username, password);
            System.out.println("Connected to " + URL);
            return con;
            
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    // end getConnection()
    
    
    
    public static void main(String args[])
    {
        System.out.println("Getting connection to database");
        try {
            getConnection();
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
        
        // call loader function
        
            
    }
    
    
}
// end class