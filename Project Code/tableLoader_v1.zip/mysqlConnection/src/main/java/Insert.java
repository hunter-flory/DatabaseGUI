/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Hunter
 */
import java.sql.*;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/*
*
*   Insert class contains:
*       I. Clear Functions (These are used to clear tables in sql server)
*           A. Individual Clear Functions (Clear individual tables)
*               1. clearDepartment();
*               2. clearDepartmentLocations();
*               3. clearEmployee();
*               4. clearProject();
*               5. clearWorksOn();  
*           B. Clear All Function (Calls individual clear functions,
*               + used in main method to initialize tables to prevent redundancy)
*               1. clearAll();
*       II. Insert Functions (These connect to server and execute update to specific table)
*           A. Specific Tables
*               1. department(scanner)
*               2. deptLocations(scanner)
*               3. employee(scanner)
*               4. project(scanner)
*               5. worksOn(scanner)
*           B. Insert to Table Function
*               1. insertToTable(filename)
*                   a. this function loads specified file name and sends to 
*                       parse function for specific table loading (based on content of file)
*       III. Utility Functions
*           A. Connection Functions
*               1. getConnection();
*                   a. this function establishes connection with server and returns
*                       type Connection. Used to execute queries.   
*       IV. Main Method
*           A. Description
*               1. Main establishes a connection to server, clears all tables, and calls insertToTable for each file in project folder 
*
*
*/


public class Insert
{
/*
*   BEGIN PROGRAM
*   
*   <I.> BEGIN CLEAR FUNCTIONS
*
*
*
*
*/
    // this function clears the department table
    public static void clearDepartment()
    {
        // this query deletes all rows from table
        // without deleting the table
        String query = "DELETE FROM department;";
        try 
        {
            // this gets a connection with provided parameters from getConnection method we created
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();                   
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            // This prints the query 
            System.out.println(query);
        }
        
    }
    // END CLEARDEPARTMENT

    // this function clears dept_locations table
    public static void clearDepartmentLocations()
    {
        // this query deletes all rows from table
        // without deleting the table
        String query = "DELETE FROM dept_locations;";
        try 
        {
            // this gets a connection with provided parameters from getConnection method we created
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();                   
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            // This prints the query 
            System.out.println(query);
        }
        
    }
    // END CLEARDEPARTMENTLOCATIONS

    // this function clears employee table
    public static void clearEmployee()
    {
        // this query deletes all rows from table
        // without deleting the table
        String query = "DELETE FROM employee;";
        try 
        {
            // this gets a connection with provided parameters from getConnection method we created
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();                   
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            // This prints the query 
            System.out.println(query);
        }
        
    }
    // END CLEAREMPLOYEE
  
    // this function clears project table
    public static void clearProject()
    {
        // this query deletes all rows from table
        // without deleting the table
        String query = "DELETE FROM project;";
        try 
        {
            // this gets a connection with provided parameters from getConnection method we created
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();                   
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            // This prints the query 
            System.out.println(query);
        }
        
    }
    // END CLEARPROJECT
  
    // this function clears works_on table
    public static void clearWorksOn()
    {
        // this query deletes all rows from table
        // without deleting the table
        String query = "DELETE FROM works_on;";
        try 
        {
            // this gets a connection with provided parameters from getConnection method we created
            Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.executeUpdate();                   
        }
        catch (Exception e)
        {
            System.out.println(e);
        }
        finally
        {
            // This prints the query 
            System.out.println(query); 
        }
        
    }
    // END CLEARWORKSON
 
    // WARNING:
    // This function clears all rows in all tables
    // Use it to clear all tables if you inserted files twice or need to test
    public static void clearAll()
    {
        clearDepartment();
        clearDepartmentLocations();
        clearEmployee();
        clearProject();
        clearWorksOn();             
    }
    // END CLEARALL
/*  
*
*
*   <I./>END CLEAR FUNCTIONS 
*
*   <II.> BEGIN INSERT FUNCTIONS
*
*
*/
    // this is the specific function to populate department table
    public static void department(Scanner input)
    {
        // Department.txt has name, department number, manager number and date in that order
        String name, dept_num, manager_num, date;
        
        // this will be used with prepared statment to query sql server
        String query;
          
        // this while statement breaks down the Department data 
        // into variables for insert
        while (input.hasNextLine())
        {
            String line = input.nextLine();
            String delims = "[,\n]";
            String[] tokens = line.split(delims);

            name = tokens[0];
            dept_num = tokens[1];
            manager_num = tokens[2];
            date = tokens[3];
                        
            // this string is the SQL query
            query = "INSERT INTO department VALUES "
                    + "(" + name + ", " + dept_num + ", " + manager_num + ", " + date + ");";
                        
            try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
            
        }
        // END WHILE   
    }
    // END DEPARTMENT FUNCTION

    // this is the function that inputs location data specific to the file format
    public static void deptLocations(Scanner input)
    {
        // DEPT_LOCATIONS just has locations
        String number, locations;
        String query;
        
        while (input.hasNextLine())
        {
            String line = input.nextLine();
            String delims = "[,\n]";
            String[] tokens = line.split(delims);
            
            number = tokens[0];
            locations = tokens[1];
            
            // this string is the SQL query
            query = "INSERT INTO dept_locations VALUES "
                    + "("+number + ", "+locations+");";
            
            try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
            
        }
        // END WHILE
    }
    // END DEPTLOCATIONS FUNCTION
    
    
    public static void employee(Scanner input)
    {
        String fname, minit, lname, emp_number, bdate, address, sex, salary, 
                supervisor_num, dept_num;
        String query;
        
        while (input.hasNextLine())
        {
            String line = input.nextLine();
            // this regex says:
            // comma followed by a whitespace
            String regex = ",(?=\\s)";
            // the -1 is used to prevent split from terminating when null is found
            String[] tokens = line.split(regex, -1);
            fname = tokens[0];
            minit = tokens[1];
            lname = tokens[2];
            emp_number = tokens[3];
            bdate = tokens[4];
            address = tokens[5];
            sex = tokens[6];
            salary = tokens[7];
            supervisor_num = tokens[8];
            dept_num = tokens[9];
            
            // this string is the SQL query
            query = "INSERT INTO employee VALUES "
                    + "("+fname + ", "+minit+ ", " +lname+ ", "+emp_number
                    + ", "+bdate+ ", "+address+ ", "+sex+ ", "+salary
                    + ", "+supervisor_num+ ", "+dept_num+");";
            
            try 
            {
                // this gets a connection with provided parameters from getConnection method we created
                Connection connection = getConnection();
                PreparedStatement statement = connection.prepareStatement(query);
                statement.executeUpdate();                   
            }
            catch (Exception e)
            {
                System.out.println(e);
            }
            finally
            {
                // This prints the query 
                System.out.println(query);
            }
            
        }
        // END WHILE
    }
    // END EMPLOYEE FUNCTION
    
    public static void project(Scanner input)
    {
        
    }
    // END PROJECT FUNCTION
    
    
    public static void worksOn(Scanner input)
    {
        
    }
    // END WORKSON FUNCTION

    // call this function with the full filename as a parameter to open it
    // and scan for database entries
    // THIS IS INCOMPLETE
    public static void insertToTable(String fileName)
    {
        
        try (Scanner input = new Scanner(new File(fileName)))
        {

            switch (fileName) // parse each file differently depending on datatype/name
            {
                case "DEPARTMENT.txt" -> {
                    department(input);
                }
                case "DEPT_LOCATIONS.txt" -> {
                    deptLocations(input);
                }
                case "EMPLOYEE.txt" -> {
                    employee(input);
                }
                case "PROJECT.txt" -> {
                    project(input);
                }
                case "WORKS_ON.txt" -> {
                    worksOn(input);
                }
                // i moved these files to the project folder itself
                default -> System.out.println("File not supported. Use files found in src/Database_Entries"); 
                
            }
                
        }
        catch (IOException e)
        {
            System.out.println(e);
        }
    }
    // END INSERTTOTABLE
/*
*
*   END INSERT FUNCTIONS
*
*   BEGIN UTILITY FUNCTIONS
*
*
*/
    // get connection method, returns null if it doesn't work
    public static Connection getConnection() throws Exception{
        try{
            // unnecesary but i'm following the tutorial
            String driver = "com.mysql.cj.jdbc.Driver";
            // found under connection properties
            String URL = "jdbc:mysql://localhost:3306/mydb?zeroDateTimeBehavior=CONVERT_TO_NULL";
            // username and password i set for myself in server
            String username = "hunter";
            String password = "hunter";
            // loads driver, again unnecessary
            Class.forName(driver);
            
            Connection con = DriverManager.getConnection(URL, username, password);
            return con;
            //System.out.println("Connection Established.");
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
    // END GETCONNECTION
/*
*
*   END UTILITY FUNCTIONS
*
*   BEGIN MAIN METHOD
*
*
*/
    // MAIN METHOD
    public static void main(String[] args) throws Exception
    {
        // connection is established through netbeans to sql server
        // INSTRUCTIONS: under 'Services', right click 'Databases' and click 'New Connection'
        // Select the driver you are using for the connection (I'm using Connector J 8.0.21 found from MySQL Community Installer)
        // Browse for the file path to the driver jar you downloaded 
        // Use 'localhost' as Host, port as 3306, and the name of the database ('mysql', or whatever you changed it to)
        // The username and passwords I set up for my local server is your lowercase first name for both
        // Test the connection to see if it worked and you're done. 
        // Your connection should now show up under the 'Services' tab
        // You can find 'mydb' under 'Other databases'
        
        
        // TODO: finish readFile function and write prepared statements to insert 
        // data files into tables
        //System.out.println("Beginning Program");
        getConnection();
        
        // initializes tables so records are not inserted more than once
        clearAll();
        
        // Begin inserting records to tables
        insertToTable("DEPARTMENT.txt");
        insertToTable("DEPT_LOCATIONS.txt");
        insertToTable("EMPLOYEE.txt");
    }
}
/*
*   
*   END MAIN METHOD
*
*
*   END PROGRAM
*
*/